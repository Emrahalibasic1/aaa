---
name: Sistem za upravljanje timovima i zadacima
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#434655'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#712ae2'
  on-secondary: '#ffffff'
  secondary-container: '#8a4cfc'
  on-secondary-container: '#fffbff'
  tertiary: '#006243'
  on-tertiary: '#ffffff'
  tertiary-container: '#007d57'
  on-tertiary-container: '#bdffdc'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#eaddff'
  secondary-fixed-dim: '#d2bbff'
  on-secondary-fixed: '#25005a'
  on-secondary-fixed-variant: '#5a00c6'
  tertiary-fixed: '#85f8c4'
  tertiary-fixed-dim: '#68dba9'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005137'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.625rem
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.25rem
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.6875rem
    fontWeight: '700'
    lineHeight: 0.875rem
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

This design system is tailored for community engagement, volunteer coordination, and non-profit team execution. Rather than the dense, utilitarian, and fatigue-inducing complexity of enterprise issue trackers, it prioritizes warmth, legibility, and effortless task orchestration.

### Personality & Tone
- **Warm & Empathetic:** The interface feels encouraging, humane, and collaborative rather than rigid or punitive.
- **Clarity-Driven:** Generous negative space, purposeful contrast, and distinct team color coding eliminate visual friction for volunteers balancing tasks alongside other commitments.
- **Approachable Modernity:** Balances the reliability of modern productivity software with soft, tactile visual elements that reward completion and collective momentum.

### Visual Style
A hybrid of **Modern Clean Minimalism** and **Tactile Soft UI**:
- Surfaces rely on balanced white and cool-slate foundations accented by crisp, luminous team markers.
- Geometry balances structured desktop-first information density with friendly, rounded cards and subtle depth.
- Statuses and teams are immediately recognizable through distinct, accessible color coding calibrated for both light and dark environments.

## Colors

The color palette pairs an uncluttered neutral core with vibrant, high-contrast semantic channels for cross-functional volunteer departments and urgent task states.

### Core Neutral Palettes
- **Light Theme Canvas:** Base application backdrop is `#F8FAFC`, card and panel surfaces rest on `#FFFFFF`, with subtle dividing borders in `#E2E8F0` and interactive hovers in `#F1F5F9`.
- **Dark Theme Canvas:** Base application backdrop is `#0F172A`, surface cards elevate to `#1E293B`, subtle borders utilize `#334155`, and interactive hover surfaces scale to `#27354A`.
- **Text & Contrast:** 
  - Light mode primary copy is `#0F172A` (Slate 900), secondary copy `#475569` (Slate 600), and muted metadata `#64748B` (Slate 500).
  - Dark mode primary copy is `#F8FAFC` (Slate 50), secondary copy `#CBD5E1` (Slate 300), and muted metadata `#94A3B8` (Slate 400).

### Team Signature Accents
Each department carries an unmistakable identity token used in badges, avatars, column headers, and active state indicators:
- **Dizajn (Design):** Vivid Violet (`#8B5CF6` Light Mode, `#A78BFA` Dark Mode). Surface tint: `#F5F3FF` (Light) / `rgba(139, 92, 246, 0.15)` (Dark).
- **IT (Tehnologija):** Electric Indigo/Blue (`#2563EB` Light Mode, `#60A5FA` Dark Mode). Surface tint: `#EFF6FF` (Light) / `rgba(37, 99, 235, 0.15)` (Dark).
- **PR (Odnosi s javnošću):** Energetic Amber/Coral (`#EA580C` Light Mode, `#FB923C` Dark Mode). Surface tint: `#FFF7ED` (Light) / `rgba(234, 88, 12, 0.15)` (Dark).
- **HR (Ljudski resursi):** Emerald Green (`#059669` Light Mode, `#34D399` Dark Mode). Surface tint: `#ECFDF5` (Light) / `rgba(5, 150, 105, 0.15)` (Dark).
- **Edu (Edukacija):** Vivid Cyan/Teal (`#0891B2` Light Mode, `#22D3EE` Dark Mode). Surface tint: `#ECFEFF` (Light) / `rgba(8, 145, 178, 0.15)` (Dark).

### Task Priority Indicators
- **Nizak (Low):** Neutral Slate/Blue (`#64748B` text on `#F1F5F9` background; dark mode `#94A3B8` on `#1E293B`).
- **Srednji (Medium):** Warm Amber (`#D97706` text on `#FEF3C7` background; dark mode `#FBBF24` on `rgba(217, 119, 6, 0.2)`).
- **Visok (High):** Vibrant Rose (`#E11D48` text on `#FFE4E6` background; dark mode `#FB7185` on `rgba(225, 29, 72, 0.2)`).
- **Kritično / Isteklo (Overdue/Urgent):** Solid Crimson Crimson (`#DC2626` text on `#FEE2E2` background; dark mode `#F87171` on `rgba(220, 38, 38, 0.25)`).

## Typography

The typography leverages **Plus Jakarta Sans** across all levels to balance clean geometric legibility with warm, approachable open apertures. It provides native support for Central European diacritics (č, ć, dž, đ, š, ž) critical for the Bosnian language interface.

### Typographic Hierarchy
- **Primary Page Headers (`headline-xl`, `headline-lg`):** Reserved for module views (e.g., *Pregled zadataka*, *Moji timovi*). Uses tight letter spacing and bold weights to ground the desktop workspace.
- **Card & Section Titles (`headline-md`, `headline-sm`):** Bold, scannable anchors for Kanban column headers, modal titles, and task summaries.
- **Body Text (`body-lg`, `body-md`, `body-sm`):** Set at relaxed line heights to accommodate task descriptions, volunteer onboarding instructions, and comment threads.
- **Labels & Badges (`label-md`, `label-sm`):** High-weight, slightly tracked tokens optimized for uppercase or capitalized category markers (e.g., *DODIJELJENO*, *ROK*, *AKTIVNO*).

## Layout & Spacing

The application employs a desktop-optimized responsive layout designed to accommodate multi-column boards, task lists, and detailed flyout side-drawers without cramped overcrowding.

### Structure & Grid
- **Desktop Layout:** Fixed navigation sidebar (260px expanded, 72px collapsed) accompanied by a fluid main content canvas with a minimum margin of `2rem` (`32px`).
- **Board Grid:** Kanban and workflow boards utilize a fixed-fluid hybrid column model: columns maintain a minimum width of `300px` and snap to horizontal scroll on smaller monitors, preserving task card clarity.
- **Table & List Density:** Row heights are kept spacious (`56px` to `64px`) to preserve touch targets and prevent volunteer cognitive fatigue.
- **Responsive Adaptations:** 
  - On screens under `1024px`, the primary navigation collapses into an off-canvas drawer.
  - On mobile (`<640px`), multi-column boards reflow into tabbed views segmented by status (e.g., *Za uraditi*, *U toku*, *Završeno*), and outer margins reduce to `1rem` (`16px`).

## Elevation & Depth

Visual hierarchy avoids heavy drop shadows, relying instead on tonal elevation, crisp boundary definition, and delicate ambient light diffusion.

### Elevation Levels
- **Level 0 (Flat Canvas):** The base background (`#F8FAFC` light / `#0F172A` dark). Carries zero shadow.
- **Level 1 (Surface Cards & Kanban Columns):** Used for standard task cards, dashboard widgets, and white content containers. Framed by a 1px border (`#E2E8F0` light / `#334155` dark) with a diffuse ambient shadow:
  - `box-shadow: 0 1px 3px 0 rgba(15, 23, 42, 0.04), 0 1px 2px -1px rgba(15, 23, 42, 0.03)`
- **Level 2 (Hovered Cards & Dropdowns):** Interactive states when picking up or hovering over a task card. Border softens, accompanied by a buoyant elevation:
  - `box-shadow: 0 10px 15px -3px rgba(15, 23, 42, 0.08), 0 4px 6px -4px rgba(15, 23, 42, 0.03)`
- **Level 3 (Modals, Task Drawers & Floating Action Bars):** Highest focal tier for detailed task editing drawers and alert overlays:
  - `box-shadow: 0 20px 25px -5px rgba(15, 23, 42, 0.12), 0 8px 10px -6px rgba(15, 23, 42, 0.06)`
  - Backdropped with a softened blur overlay: `backdrop-filter: blur(6px); background: rgba(15, 23, 42, 0.45)`.

## Shapes

The interface embraces organic, comfortable corner treatments to convey warmth and accessible usability, departing completely from harsh boxy lines.

### Radius Conventions
- **Standard Controls & Badges (0.5rem / 8px):** Form inputs, buttons, priority tags, and filter pills.
- **Cards & Content Blocks (1rem / 16px):** Standard task cards, summary widgets, and notifications.
- **Containers & Modals (1.5rem / 24px):** Large task detail drawers, dialogue modals, and board column backdrops.
- **Full Rounded (9999px):** Avatar icons, status dot containers, and floating interaction triggers.

## Components

### Buttons
- **Primary Action (npr. *Novi zadatak*, *Sačuvaj*):** Filled solid with primary blue (`#2563EB`) or team-specific action accents. Text is bold white (`#FFFFFF`), corner radius is `0.5rem`, height `40px` desktop / `44px` mobile, padding `0 1rem`. Focus states feature a crisp 2px offset ring.
- **Secondary Action (npr. *Otkaži*, *Filtriraj*):** White card surface (`#FFFFFF`) with a 1px border in `#E2E8F0` and slate copy (`#334155`). On hover, switches to `#F8FAFC`.
- **Subtle / Ghost:** Transparent background with `#64748B` text, shifting to `#F1F5F9` on hover. Used for auxiliary operations like table menu triggers and drawer close buttons.

### Task Cards
- Constructed with a `1rem` (16px) radius, white background, 1px `#E2E8F0` border, and Level 1 elevation.
- **Header:** Features a top team tag (e.g., `Dizajn`, `IT`) accompanied by the task priority badge.
- **Body:** Concise task headline (`headline-sm`) followed by optional two-line snippet (`body-sm`).
- **Footer:** Team member avatar stack on the left, visual deadline indicator (*npr. "Do sutra"*, *"12. maj"*) with a clock icon on the right. Overdue items style the deadline in crimson red (`#DC2626`).

### Badges & Chips
- **Team Badges:** Lightweight pill style with background tint (10% opacity of the team color) and bold colored text (e.g., Dizajn: `#7C3AED` text on `#F5F3FF` background).
- **Priority Chips:** Pill-shaped (`rounded-full`), `label-sm` font, incorporating a 6px status circle preceding the label (*Nizak*, *Srednji*, *Visok*, *Isteklo*).

### Form Inputs & Search
- Inputs feature a generous `42px` height, `0.5rem` border-radius, `#F8FAFC` background (shifting to pure `#FFFFFF` on focus), and a 1px `#CBD5E1` border.
- Active focus displays an electric blue border (`#2563EB`) and a soft outer glow ring (`box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15)`).
- Search input includes an integrated quick-clearing icon and placeholder text (*"Pretraži zadatke, volontere ili timove..."*).

### Checkboxes & Progress Indicators
- **Task Completion Checkbox:** Oversized `20x20px` square with `6px` rounded corners. Default border is `#94A3B8`. When completed, fills with Emerald Green (`#059669`) with a crisp white checkmark, accompanied by an animated strike-through across the adjacent task label.
- **Progress Trackers:** Compact `6px` linear bars displaying team workload or sprint progress with smooth rounded end-caps.