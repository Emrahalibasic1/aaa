---
name: VolonteriHub Dark Mode
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#8c909f'
  outline-variant: '#424754'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e6a'
  primary-container: '#4d8eff'
  on-primary-container: '#00285d'
  inverse-primary: '#005ac2'
  secondary: '#cebdff'
  on-secondary: '#381385'
  secondary-container: '#4f319c'
  on-secondary-container: '#bea8ff'
  tertiary: '#45dfa4'
  on-tertiary: '#003825'
  tertiary-container: '#00a574'
  on-tertiary-container: '#003120'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#e8ddff'
  secondary-fixed-dim: '#cebdff'
  on-secondary-fixed: '#21005e'
  on-secondary-fixed-variant: '#4f319c'
  tertiary-fixed: '#68fcbf'
  tertiary-fixed-dim: '#45dfa4'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005137'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
  bg-canvas: '#0b0f19'
  bg-surface: '#0f172a'
  bg-container: '#1e293b'
  bg-container-high: '#27354a'
  border-subtle: '#1e293b'
  border-default: '#334155'
  border-focused: '#60a5fa'
  text-primary: '#f8fafc'
  text-secondary: '#e2e8f0'
  text-muted: '#94a3b8'
  blue-accent-light: '#60a5fa'
  team-design: '#a78bfa'
  team-it: '#60a5fa'
  team-pr: '#fb923c'
  team-hr: '#34d399'
  team-edu: '#22d3ee'
  priority-low: '#94a3b8'
  priority-medium: '#fbbf24'
  priority-high: '#fb7185'
  priority-critical: '#f87171'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.025em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.375rem
    fontWeight: '700'
    lineHeight: 1.75rem
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.625rem
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.8125rem
    fontWeight: '400'
    lineHeight: 1.25rem
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.6875rem
    fontWeight: '700'
    lineHeight: 0.875rem
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

This design system establishes a dedicated nocturnal environment for volunteer coordination, community operations, and task execution under sustained low-light conditions. Volunteer work frequently takes place outside conventional working hours—late evenings and nights—requiring an interface engineered to prevent visual fatigue while preserving the energizing, collaborative spirit of civic work.

### Aesthetic Direction: Modern Atmospheric Dark
The design language combines **Modern Slate Minimalism** with **Luminous Chromatic Accents**. Rather than relying on stark, pitch-black canvases, the environment builds on deep obsidian and navy-slate substrates (`#0b0f19`, `#0f172a`, `#1e293b`). Subtle light emission, crisp perimeter delineation, and vibrant electric blue signifiers give interfaces structure and focus.

### Tone and Brand Pillars
- **Ergonomic & Calm:** Reduced luminance preserves volunteer eye comfort during extended nighttime management sessions.
- **Empathetic & Structured:** Deep tonal layering prevents claustrophobia, allowing multi-team task queues and volunteer directories to remain legible and approachable.
- **Vibrant & Decisive:** High-contrast luminous text and calibrated semantic glows ensure overdue deadlines, task states, and departmental badges stand out instantly without causing glare.

## Colors

The dark mode palette uses calculated luminance tiers to construct depth without eye strain, moving from a deep base canvas to elevated container surfaces, illuminated by luminous departmental badges and status indicators.

### Surface System
- **Base Canvas (`#0b0f19`):** Foundational backdrop for screen real estate and board canvas gutters.
- **Surface Level (`#0f172a`):** Navigation rails, top app bars, and stationary board column wells.
- **Card Container (`#1e293b`):** Standard resting state for individual task cards, form groups, and dialog containers.
- **Interactive Container (`#27354a`):** Hovered cards, selected rows, and pressed utility items.

### Content & Typography Contrast
- **High-Contrast Primary Text (`#f8fafc`):** Applied to headlines, active titles, and input labels for crisp readability.
- **Secondary Body Text (`#e2e8f0`):** Used for task summaries, onboarding documentation, and volunteer bios.
- **Muted Metadata (`#94a3b8`):** Subordinate timestamps, icons, column counts, and secondary tags.

### Department Accents (Dark Mode Tinting)
Department tags are paired with a 15% opacity solid background to eliminate halo glare while maintaining rapid visual triage:
- **Dizajn (Design):** Text `#a78bfa` on `rgba(167, 139, 250, 0.15)`.
- **IT (Tehnologija):** Text `#60a5fa` on `rgba(96, 165, 250, 0.15)`.
- **PR (Odnosi s javnošću):** Text `#fb923c` on `rgba(251, 146, 60, 0.15)`.
- **HR (Ljudski resursi):** Text `#34d399` on `rgba(52, 211, 153, 0.15)`.
- **Edu (Edukacija):** Text `#22d3ee` on `rgba(34, 211, 238, 0.15)`.

### Priority & Status Tints
- **Nizak (Low):** Neutral `#94a3b8` indicator with `#1e293b` badge backing.
- **Srednji (Medium):** Amber `#fbbf24` text on `rgba(251, 191, 36, 0.18)` surface.
- **Visok (High):** Vibrant Rose `#fb7185` text on `rgba(251, 113, 133, 0.18)` surface.
- **Kritično / Isteklo (Overdue/Urgent):** Bright Coral-Crimson `#f87171` text on `rgba(248, 113, 113, 0.22)` surface.

## Typography

The typography continues the use of **Plus Jakarta Sans** across all levels. In dark mode, light text against dark backgrounds can perceive artificial weight blooming (irradiation phenomenon). Therefore, typography weights are balanced with optical breathing room and specific mobile scaling.

### Hierarchy & Application Rules
- **Headline XL / LG:** Used strictly for primary module headlines (e.g., *Moji zadaci*, *Upravljanje timom*). Text defaults to `#f8fafc`.
- **Headline MD / SM:** Anchors column titles, modal banners, and interactive card headers.
- **Body Hierarchy (`body-lg`, `body-md`, `body-sm`):** Rendered in `#e2e8f0` for body copy and `#94a3b8` for supplementary descriptions, providing clear scannability without high-luminance fatigue.
- **Labels (`label-lg`, `label-md`, `label-sm`):** Tracked slightly wider to ensure micro-tags such as *U TOKU*, *DODIJELJENO*, and *ISTEKLO* remain crisp at small sizes. Full character support for Bosnian diacritics (č, ć, dž, đ, š, ž) is maintained across all weights.

## Layout & Spacing

Dark mode interfaces require deliberate layout spacing to avoid cards appearing clustered in low light. A disciplined rhythmic scale provides clear visual separation.

### Layout Grid and Responsive Adaptation
- **Desktop (1024px+):** Left fixed navigation rail (260px expanded, 72px collapsed). Content area utilizes a minimum page margin of `2rem` (`32px`) with `1.5rem` (`24px`) gutters between grid columns.
- **Kanban Columns:** Maintain a strict minimum width of `320px` per column lane, allowing horizontal overflow scrolling without crushing card contents.
- **Tablet (768px - 1023px):** Navigation tucks into a sliding drawer. Grid collapses to 2 columns with `1.5rem` gutters.
- **Mobile (<768px):** Kanban lanes switch to a single-column layout with status tabs (*Za uraditi*, *U toku*, *Završeno*). Lateral margins contract to `1rem` (`16px`).

## Elevation & Depth

In a dark environment, traditional drop shadows become nearly invisible against dark surfaces. Depth is established through **tonal elevation tiers**, **luminous borders**, and **subtle ambient glow filters**.

### Depth Hierarchy
- **Level 0 (Base Canvas):** `#0b0f19`. Pure foundational plane. Zero elevation or shadow.
- **Level 1 (Resting Cards & Columns):** `#1e293b` sitting on `#0f172a` column trays. Delineated by a 1px border in `#334155`. Ambient shadow: `0 2px 4px 0 rgba(0, 0, 0, 0.35)`.
- **Level 2 (Hovered / Lifted Cards):** Surface elevated to `#27354a`. Border lights up to `#475569`. Diffuse shadow: `0 12px 24px -4px rgba(0, 0, 0, 0.5), 0 0 0 1px rgba(96, 165, 250, 0.2)`.
- **Level 3 (Modals, Overlays & Flyout Drawers):** `#0f172a` backdrop framed by a 1px border in `#3b82f6` at 30% opacity. Shadow: `0 25px 50px -12px rgba(0, 0, 0, 0.75)`. Modals use a darkened frosted backdrop scrim: `backdrop-filter: blur(8px); background: rgba(11, 15, 25, 0.7)`.

## Shapes

The design system maintains friendly, approachable forms that balance modern operational structure with community warmth. Sharp corners are avoided.

### Radius Assignments
- **Input Controls & Small Buttons (0.5rem / 8px):** Select fields, standard buttons, text inputs, search bars, and tags.
- **Cards & Surface Widgets (1rem / 16px):** Standard task cards, team profile cards, and column summary headers.
- **Modals & Drawers (1.5rem / 24px):** Large task details, side sheet panels, and floating notification dialogues.
- **Pills & Avatars (9999px):** Volunteer profile images, priority indicator pills, and floating action triggers.

## Components

### Buttons
- **Primary Action (npr. *Novi zadatak*, *Sačuvaj*):** Background `#3b82f6` transitioning to `#2563eb` on hover. Text `#ffffff` in `label-lg` weight. Corner radius `0.5rem`. Height `40px`. Focus states utilize a 2px offset ring in `#60a5fa`.
- **Secondary Action (npr. *Otkaži*, *Filtriraj*):** Background `#1e293b` with a 1px border in `#334155`. Text `#e2e8f0`. On hover, the surface shifts to `#27354a` and text to `#f8fafc`.
- **Ghost Action:** Transparent background with `#94a3b8` text, shifting to `rgba(255, 255, 255, 0.05)` surface and `#f8fafc` text on interaction.

### Task Cards
- Built on `#1e293b` with a 1px `#334155` outline and `1rem` corner rounding.
- **Header:** Houses the departmental tag pill (e.g., Dizajn in `#a78bfa`) adjacent to the priority pill.
- **Body:** Task title set in `headline-sm` with high-contrast `#f8fafc`, accompanied by optional body preview in `#94a3b8`.
- **Footer:** Team member avatar overlapping stack on the left; formatted deadline badge on the right with a calendar/clock icon. Overdue dates transition to `#f87171` text on `rgba(248, 113, 113, 0.2)`.

### Badges & Chips
- **Team Badges:** Lightweight pill style with 15% opacity background tint and bold saturated foreground text (e.g., IT: `#60a5fa` text on `rgba(96, 165, 250, 0.15)`).
- **Priority Badges:** Rounded pill container featuring a 6px status dot followed by uppercase label text in `label-sm`.

### Form Inputs & Search Fields
- Base height `42px`, border-radius `0.5rem`, `#0b0f19` background fill, and a 1px `#334155` border.
- Text entered renders in `#f8fafc`; placeholder displays `#64748b`.
- **Active Focus:** Border transitions to `#60a5fa` accompanied by an ambient glow ring: `box-shadow: 0 0 0 3px rgba(96, 165, 250, 0.2)`.
- Search bars include an embedded magnifying glass icon in `#94a3b8` and a quick-clear escape button.

### Checkboxes & Status Toggles
- **Task Checkboxes:** `20x20px` container with `0.375rem` (6px) rounded corners. Resting border is `#475569` against `#0f172a`. On check, transitions to `#34d399` fill with a `#0b0f19` checkmark icon, triggering a strikethrough animation across the card title in `#64748b`.
- **Progress Trackers:** Compact `6px` track in `#1e293b` filled with an accent gradient from `#3b82f6` to `#60a5fa` with rounded end-caps.